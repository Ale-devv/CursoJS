// Unknown é basicamente um Any, só que mais seguro.

let x: unknown;

x = 100;
x = 'Alisson';
x = 900;
x = '10';
const y = 800;

if (typeof x === 'number') console.log(x + y);
