// tuple

const dadosCliente1 = readonly [number, string] = [1, 'Alisson'];
const dadosCliente2 = [number, string, string] = [1, 'Alisson', 'Oliveira'];
const dadosCliente3 = [number, string, string?] = [1, 'Alisson',];
const dadosCliente4 = [number, string, ...string[]] = [1, 'Alisson', 'Oliveira'];

dadosCliente1 [0] = 100;
dadosCliente1 [1] = 'Alisson';


console.log(dadosCliente1)
console.log(dadosCliente2)
console.log(dadosCliente3)
console.log(dadosCliente4)

// readonly array
const array: readonly string[] = ['Alisson', 'Oliveira'];
const array2: ReadonlyArray<string> = ['Alisson', 'Oliveira'];


console.log(array);
console.log(array2);