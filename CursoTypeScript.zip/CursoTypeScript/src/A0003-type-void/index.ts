function semRetoro(...args: string[]): void {
  console.log(args.join(' '));
}

const pessoa = {
  nome: 'Alisson',
  sobrenome: 'Oliveira',

  exibirNome(): void {
    console.log(this.nome + ' ' + this.sobrenome);
  },
};

semRetoro('Alissn', 'Oliveira');
pessoa.exibirNome();

export { pessoa };

// void: quando uma função ou um método não reotrna nada
